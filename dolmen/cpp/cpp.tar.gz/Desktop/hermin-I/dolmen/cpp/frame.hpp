#ifndef DOLMEN_FRAME_HPP
#define DOLMEN_FRAME_HPP value

namespace dolmen {

class frame {
private:
  /* data */

public:
  string frame;

  void save()
  {
    return;
  }


  frame (arguments);
  virtual ~frame ();
};

} /* dolmen */

#endif
