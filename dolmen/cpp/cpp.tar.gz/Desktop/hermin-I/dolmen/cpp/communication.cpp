/*#include "communication.hpp"

namespace dolmen
{
  //
} *//* dolmen */
