#include "factorySensor.hpp"

namespace dolmen
{
  //code
} /* dolmen */
